#ifndef NETWORK_H
#define NETWORK_H

#include <netinet/in.h>

int Network_Init(void);

void Network_Run(void);

void Network_Close(void);

int Network_KickPlayer(int playerID);
int Network_Broadcast(const char *message);

/* Sends message as-is to every connected player, with no "BROADCAST "
 * prefix added. Used for protocol packets like UPDATE/PONG. */
int Network_BroadcastRaw(const char *message);

/* Sends message as-is to a single specific address (no player lookup). */
int Network_SendTo(const char *message, const struct sockaddr_in *address);

int Network_GetSocket(void);

#endif
