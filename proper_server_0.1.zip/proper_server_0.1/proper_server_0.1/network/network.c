#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "network.h"

#include "../logger/logger.h"
#include "../src/config.h"
#include "../player/player.h"

#include "../packet/dispatcher.h"
#include "../packet/hello.h"
#include "../packet/move.h"
#include "../packet/ping.h"
#include "../packet/disconnect.h"
#include "../packet/heartbeat.h"

#include "../core/server_stats.h"
#include "../dashboard/dashboard.h"


static int serverSocket = -1;

static struct sockaddr_in serverAddr;
static struct sockaddr_in clientAddr;


/* Forward declaration */
void Network_Close(void);


/* ============================================================
 * KICK PLAYER
 * ============================================================ */
int Network_KickPlayer(int playerID)
{
    const struct sockaddr_in *address;
    const char message[] = "KICK";
    int sent;

    if (serverSocket < 0)
        return -1;

    address = Player_GetAddress(playerID);

    if (address == NULL)
        return -1;

    sent = sendto(serverSocket,
                  message,
                  sizeof(message) - 1,
                  0,
                  (const struct sockaddr *)address,
                  sizeof(*address));

    if (sent < 0)
    {
        Logger_Log(LOG_WARNING,
                   "Failed to send KICK packet");

        return -1;
    }

    ServerStats_IncrementTX();

    Player_Remove(playerID);
    ServerStats_ClientDisconnected();

    return 0;
}


/* ============================================================
 * BROADCAST
 *
 * Adds:
 *
 *     BROADCAST
 *
 * before the message.
 *
 * Example:
 *
 *     broadcast Hello
 *
 * becomes:
 *
 *     BROADCAST Hello
 * ============================================================ */
int Network_Broadcast(const char *message)
{
    char packet[BUFFER_SIZE];

    const struct sockaddr_in *address;

    int id;
    int sent;
    int delivered;

    if (serverSocket < 0 ||
        message == NULL ||
        message[0] == '\0')
    {
        return -1;
    }

    snprintf(packet,
             sizeof(packet),
             "BROADCAST %s",
             message);

    delivered = 0;

    for (id = 1; id <= MAX_PLAYERS; id++)
    {
        address = Player_GetAddress(id);

        if (address == NULL)
            continue;

        sent = sendto(serverSocket,
                      packet,
                      strlen(packet),
                      0,
                      (const struct sockaddr *)address,
                      sizeof(*address));

        if (sent >= 0)
        {
            ServerStats_IncrementTX();
            delivered++;
        }
    }

    return delivered;
}


/* ============================================================
 * CLOSE NETWORK
 * ============================================================ */
void Network_Close(void)
{
    if (serverSocket >= 0)
    {
        close(serverSocket);
        serverSocket = -1;
    }
}


/* ============================================================
 * GET SOCKET
 * ============================================================ */
int Network_GetSocket(void)
{
    return serverSocket;
}


/* ============================================================
 * SEND TO ONE PLAYER
 * ============================================================ */
int Network_SendTo(const char *message,
                   const struct sockaddr_in *address)
{
    int sent;

    if (serverSocket < 0 ||
        message == NULL ||
        address == NULL)
    {
        return -1;
    }

    sent = sendto(serverSocket,
                  message,
                  strlen(message),
                  0,
                  (const struct sockaddr *)address,
                  sizeof(*address));

    if (sent < 0)
        return -1;

    ServerStats_IncrementTX();

    return sent;
}


/* ============================================================
 * BROADCAST RAW
 *
 * Sends the message exactly as supplied.
 *
 * Example:
 *
 *     UPDATE ID=1 X=10 Y=20 ROT=90
 *
 * ============================================================ */
int Network_BroadcastRaw(const char *message)
{
    const struct sockaddr_in *address;

    int id;
    int sent;
    int delivered;

    if (serverSocket < 0 ||
        message == NULL ||
        message[0] == '\0')
    {
        return -1;
    }

    delivered = 0;

    for (id = 1; id <= MAX_PLAYERS; id++)
    {
        address = Player_GetAddress(id);

        if (address == NULL)
            continue;

        sent = sendto(serverSocket,
                      message,
                      strlen(message),
                      0,
                      (const struct sockaddr *)address,
                      sizeof(*address));

        if (sent >= 0)
        {
            ServerStats_IncrementTX();
            delivered++;
        }
    }

    return delivered;
}


/* ============================================================
 * INITIALIZE NETWORK
 * ============================================================ */
int Network_Init(void)
{
    Logger_Log(LOG_INFO,
               "Creating UDP Socket...");

    serverSocket = socket(AF_INET,
                          SOCK_DGRAM,
                          0);

    if (serverSocket < 0)
    {
        Logger_Log(LOG_ERROR,
                   "Socket Creation Failed");

        return -1;
    }


    memset(&serverAddr,
           0,
           sizeof(serverAddr));


    serverAddr.sin_family = AF_INET;

    serverAddr.sin_addr.s_addr =
        INADDR_ANY;

    serverAddr.sin_port =
        htons(SERVER_PORT);


    if (bind(serverSocket,
             (struct sockaddr *)&serverAddr,
             sizeof(serverAddr)) < 0)
    {
        printf("\nBind Failed!\n");
        printf("errno = %d\n", errno);
        printf("Reason = %s\n",
               strerror(errno));

        Logger_Log(LOG_ERROR,
                   "Bind Failed");

        close(serverSocket);
        serverSocket = -1;

        return -1;
    }


    Logger_Log(LOG_INFO,
               "UDP Server Started");

    return 0;
}


/* ============================================================
 * NETWORK RUN LOOP
 * ============================================================ */
void Network_Run(void)
{
    char buffer[BUFFER_SIZE];

    socklen_t clientLength;

    clientLength =
        sizeof(clientAddr);


    while (1)
    {
        int bytes;

        memset(buffer,
               0,
               sizeof(buffer));

        clientLength =
            sizeof(clientAddr);


        /* ----------------------------------------------------
         * WAIT FOR UDP PACKET
         * ---------------------------------------------------- */
        bytes = recvfrom(serverSocket,
                         buffer,
                         BUFFER_SIZE - 1,
                         0,
                         (struct sockaddr *)&clientAddr,
                         &clientLength);


        /* ----------------------------------------------------
         * PACKET RECEIVED
         * ---------------------------------------------------- */
        if (bytes > 0)
        {
            PacketType type;
            int knownPlayer;


            /* Count received packet */
            ServerStats_IncrementRX();


            /* Null terminate */
            buffer[bytes] = '\0';


            /* ------------------------------------------------
             * STORE LAST PACKET FOR DASHBOARD
             * ------------------------------------------------ */
            Dashboard_SetLastPacket(buffer);


            /* ------------------------------------------------
             * DEBUG INFORMATION
             * ------------------------------------------------ */
            printf("\n");
            printf("[PACKET RECEIVED]\n");
            printf("IP      : %s\n",
                   inet_ntoa(clientAddr.sin_addr));
            printf("PORT    : %d\n",
                   ntohs(clientAddr.sin_port));
            printf("PACKET  : %s\n",
                   buffer);

            /* ------------------------------------------------
             * IDENTIFY PACKET TYPE
             * ------------------------------------------------ */
            type =
                Packet_Dispatch(buffer);


            /* ------------------------------------------------
             * HEARTBEAT UPDATE
             *
             * Any packet from an already connected player
             * proves that the player is still alive.
             * ------------------------------------------------ */
            knownPlayer =
                Player_FindByAddress(&clientAddr);

            if (knownPlayer != 0)
            {
                Player_TouchHeartbeat(knownPlayer);
            }


            /* ------------------------------------------------
             * DISPATCH PACKET
             * ------------------------------------------------ */
            switch (type)
            {
                case PACKET_HELLO:

                    printf("[Dispatcher] HELLO Packet\n");

                    Hello_Handle(serverSocket,
                                 &clientAddr,
                                 clientLength);

                    break;


                case PACKET_MOVE:

                    printf("[Dispatcher] MOVE Packet\n");

                    Move_Handle(&clientAddr,
                                buffer);

                    break;


                case PACKET_PING:

                    printf("[Dispatcher] PING Packet\n");

                    Ping_Handle(&clientAddr);

                    break;


                case PACKET_DISCONNECT:

                    printf("[Dispatcher] DISCONNECT Packet\n");

                    Disconnect_Handle(&clientAddr);

                    break;


                case PACKET_CHAT:

                    /*
                     * CHAT is recognized by the dispatcher,
                     * but no CHAT handler is currently
                     * connected here.
                     */

                    printf("[Dispatcher] CHAT Packet\n");

                    break;


                case PACKET_UNKNOWN:

                default:

                    printf("[Dispatcher] UNKNOWN Packet\n");

                    break;
            }


            /* ------------------------------------------------
             * CHECK HEARTBEAT TIMEOUTS
             * ------------------------------------------------ */
            Heartbeat_CheckTimeouts();
        }


        /* ----------------------------------------------------
         * RECEIVE ERROR
         * ---------------------------------------------------- */
        else if (bytes < 0)
        {
            Logger_Log(LOG_WARNING,
                       "recvfrom failed");
        }
    }
}
