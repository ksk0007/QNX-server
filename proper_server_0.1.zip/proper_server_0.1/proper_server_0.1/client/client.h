#ifndef CLIENT_H
#define CLIENT_H

#include <netinet/in.h>

#define MAX_CLIENTS 32

typedef struct
{
    int active;

    int playerID;

    struct sockaddr_in address;

    unsigned long lastHeartbeat;

    int ping;

} Client;

void Client_Init(void);

int Client_Add(struct sockaddr_in *addr, int playerID);

void Client_Remove(int playerID);

Client* Client_Get(int playerID);

void Client_List(void);

#endif
