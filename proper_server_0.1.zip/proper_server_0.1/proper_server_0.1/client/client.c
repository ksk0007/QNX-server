#include "client.h"

#include <stdio.h>
#include <string.h>

static Client clients[MAX_CLIENTS];

void Client_Init(void)
{
    memset(clients,0,sizeof(clients));
}
