#ifndef MOVE_H_
#define MOVE_H_

#include <netinet/in.h>

/* packet is the raw text received, e.g. "MOVE X=14.22 Y=8.54 ROT=270" */
void Move_Handle(struct sockaddr_in *clientAddr, const char *packet);

#endif /* MOVE_H_ */
