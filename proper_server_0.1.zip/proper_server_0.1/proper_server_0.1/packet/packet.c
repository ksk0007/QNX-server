#include "packet.h"

#include <string.h>

void Packet_Create(Packet *pkt,
                   PacketType type,
                   unsigned int playerID)
{
    memset(pkt,0,sizeof(Packet));

    pkt->version = PACKET_VERSION;
    pkt->type = type;
    pkt->playerID = playerID;
}
