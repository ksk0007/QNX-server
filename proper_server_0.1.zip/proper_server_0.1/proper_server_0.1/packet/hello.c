#include "hello.h"

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include "../player/player.h"
#include "../logger/logger.h"
#include "../core/server_stats.h"


void Hello_Handle(
    int serverSocket,
    struct sockaddr_in *clientAddr,
    socklen_t clientLength)
{
    int playerID;
    char reply[64];
    int sent;

    playerID = Player_Add();

    if (playerID < 0)
    {
        strcpy(reply, "SERVER_FULL");

        sent = sendto(
            serverSocket,
            reply,
            strlen(reply),
            0,
            (struct sockaddr *)clientAddr,
            clientLength
        );

        if (sent < 0)
        {
            printf("[HELLO] SERVER_FULL send failed\n");
            printf("[HELLO] errno = %d\n", errno);
            printf("[HELLO] reason = %s\n", strerror(errno));
        }
        else
        {
            printf("[HELLO] SERVER_FULL sent (%d bytes)\n", sent);
            ServerStats_IncrementTX();
        }

        return;
    }


    /* Store Unity's IP + temporary UDP port */
    Player_SetAddress(playerID, clientAddr);

    ServerStats_ClientConnected();

    Logger_Log(LOG_INFO, "Player Connected");

    printf("Assigned Player ID : %d\n", playerID);

    /*
     * Build WELCOME packet
     */
    snprintf(
        reply,
        sizeof(reply),
        "WELCOME %d",
        playerID
    );


    /*
     * Show exactly where we are sending it
     */
    printf("\n");
    printf("=================================\n");
    printf("SENDING WELCOME\n");
    printf("=================================\n");

    printf("Destination IP   : %s\n",
           inet_ntoa(clientAddr->sin_addr));

    printf("Destination Port : %d\n",
           ntohs(clientAddr->sin_port));

    printf("Packet           : %s\n",
           reply);


    /*
     * Send WELCOME
     */

    sent = sendto(serverSocket,
                  reply,
                  strlen(reply),
                  0,
                  (struct sockaddr *)clientAddr,
                  clientLength);

    printf("\n=================================\n");
    printf("SENDING WELCOME\n");
    printf("Destination IP   : %s\n",
           inet_ntoa(clientAddr->sin_addr));
    printf("Destination Port : %d\n",
           ntohs(clientAddr->sin_port));
    printf("Packet           : %s\n",
           reply);
    printf("sendto() result  : %d\n",
           sent);

    if (sent < 0)
    {
        printf("sendto() FAILED\n");
        printf("errno            : %d\n",
               errno);
        printf("reason           : %s\n",
               strerror(errno));
    }
    else
    {
        printf("sendto() SUCCESS\n");
    }


    /*
     * IMPORTANT:
     * Actually check sendto()
     */
    if (sent < 0)
    {
        printf("\n");
        printf("!!!!!!!! WELCOME SEND FAILED !!!!!!!!\n");
        printf("errno  = %d\n", errno);
        printf("reason = %s\n", strerror(errno));

        Logger_Log(
            LOG_ERROR,
            "WELCOME send failed"
        );

        return;
    }


    /*
     * Only count TX if sendto() succeeded
     */
    ServerStats_IncrementTX();

    printf("WELCOME sent successfully (%d bytes)\n",
           sent);

    Logger_Log(
        LOG_INFO,
        "Reply Sent"
    );
}
