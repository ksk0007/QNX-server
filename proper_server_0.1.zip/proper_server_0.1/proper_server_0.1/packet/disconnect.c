#include "disconnect.h"

#include <stdio.h>

#include "../player/player.h"
#include "../core/server_stats.h"
#include "../logger/logger.h"

void Disconnect_Handle(struct sockaddr_in *clientAddr)
{
    int playerID;

    playerID = Player_FindByAddress(clientAddr);

    if (playerID == 0)
        return;

    printf("Player %d disconnected (client quit)\n", playerID);
    Logger_Log(LOG_INFO, "Player Disconnected");

    Player_Remove(playerID);
    ServerStats_ClientDisconnected();
}
