#ifndef PACKET_H
#define PACKET_H

#define PACKET_VERSION 1

typedef enum
{
    PKT_HELLO = 1,
    PKT_WELCOME,
    PKT_HEARTBEAT,
    PKT_PING,
    PKT_PONG,
    PKT_MOVE,
    PKT_ATTACK,
    PKT_CHAT,
    PKT_ENEMY_SPAWN,
    PKT_BOSS_START,
    PKT_GAME_STATE,
    PKT_DISCONNECT
} PacketType;

typedef struct
{
    unsigned short version;

    unsigned short type;

    unsigned int sequence;

    unsigned int playerID;

    float x;
    float y;
    float z;

    int health;
    int mana;

} Packet;

#endif
