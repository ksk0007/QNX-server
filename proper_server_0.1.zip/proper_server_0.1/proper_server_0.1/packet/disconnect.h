#ifndef DISCONNECT_H_
#define DISCONNECT_H_

#include <netinet/in.h>

void Disconnect_Handle(struct sockaddr_in *clientAddr);

#endif /* DISCONNECT_H_ */
