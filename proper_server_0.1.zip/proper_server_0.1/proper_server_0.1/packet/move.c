#include "move.h"

#include <stdio.h>
#include <string.h>

#include "../player/player.h"
#include "../network/network.h"

void Move_Handle(struct sockaddr_in *clientAddr, const char *packet)
{
    int playerID;
    float x, y, rot;
    char updateMsg[128];

    playerID = Player_FindByAddress(clientAddr);

    if (playerID == 0)
    {
        printf("[MOVE] Unknown player\n");
        return;
    }

    x = 0.0f;
    y = 0.0f;
    rot = 0.0f;

    if (sscanf(packet,
               "MOVE X=%f Y=%f ROT=%f",
               &x,
               &y,
               &rot) != 3)
    {
        printf("[MOVE] Malformed packet from player %d: %s\n",
               playerID,
               packet);

        return;
    }

    /*
     * Update server-side player state
     */
    Player_UpdatePosition(
        playerID,
        x,
        y,
        0.0f,
        rot
    );

    Player_TouchHeartbeat(playerID);

    /*
     * Create UPDATE packet
     */
    snprintf(
        updateMsg,
        sizeof(updateMsg),
        "UPDATE ID=%d X=%.2f Y=%.2f ROT=%.2f",
        playerID,
        x,
        y,
        rot
    );

    printf("[MOVE] Player %d -> X=%.2f Y=%.2f ROT=%.2f\n",
           playerID,
           x,
           y,
           rot);

    printf("[MOVE] Broadcasting: %s\n",
           updateMsg);

    Network_BroadcastRaw(updateMsg);
}
