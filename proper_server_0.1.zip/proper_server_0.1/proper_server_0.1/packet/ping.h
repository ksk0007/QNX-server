#ifndef PING_H_
#define PING_H_

#include <netinet/in.h>

void Ping_Handle(struct sockaddr_in *clientAddr);

#endif /* PING_H_ */
