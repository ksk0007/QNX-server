#ifndef HEARTBEAT_H_
#define HEARTBEAT_H_

/* Seconds of silence from a player before they are considered timed out. */
#define HEARTBEAT_TIMEOUT_SECONDS 30

/* Scans all connected players and kicks any that have gone silent
 * for longer than HEARTBEAT_TIMEOUT_SECONDS. Safe to call every tick;
 * internally only actually checks once per second. */
void Heartbeat_CheckTimeouts(void);

#endif /* HEARTBEAT_H_ */
