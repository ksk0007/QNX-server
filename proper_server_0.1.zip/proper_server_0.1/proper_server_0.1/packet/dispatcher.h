#ifndef DISPATCHER_H
#define DISPATCHER_H

typedef enum
{
    PACKET_UNKNOWN = 0,
    PACKET_HELLO,
    PACKET_MOVE,
    PACKET_PING,
    PACKET_CHAT,
    PACKET_DISCONNECT
} PacketType;

PacketType Packet_Dispatch(const char *packet);

#endif
