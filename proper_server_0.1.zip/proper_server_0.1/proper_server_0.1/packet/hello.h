#ifndef HELLO_H
#define HELLO_H

#include <netinet/in.h>

void Hello_Handle(int serverSocket,
                  struct sockaddr_in *clientAddr,
                  socklen_t clientLength);

#endif
