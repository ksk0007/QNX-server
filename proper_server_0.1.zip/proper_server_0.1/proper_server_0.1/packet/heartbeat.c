#include "heartbeat.h"

#include <stdio.h>
#include <time.h>

#include "../src/config.h"
#include "../player/player.h"
#include "../network/network.h"
#include "../logger/logger.h"

void Heartbeat_CheckTimeouts(void)
{
    static time_t lastCheck = 0;
    time_t now;
    int id;

    now = time(NULL);

    /* Throttle to once a second regardless of how often the caller ticks */
    if (now == lastCheck)
        return;

    lastCheck = now;

    for (id = 1; id <= MAX_PLAYERS; id++)
    {
        Player *p = Player_Get(id);

        if (p == NULL || !p->connected)
            continue;

        if (p->lastHeartbeat == 0)
            continue;

        if ((now - p->lastHeartbeat) > HEARTBEAT_TIMEOUT_SECONDS)
        {
            printf("Player %d timed out (no heartbeat for %ds)\n",
                   id, HEARTBEAT_TIMEOUT_SECONDS);
            Logger_Log(LOG_WARNING, "Player Timeout");

            Network_KickPlayer(id);
        }
    }
}
