#include "dispatcher.h"

#include <string.h>
#include <ctype.h>

static const char *SkipWhitespace(const char *packet)
{
    while (packet != NULL && *packet != '\0' &&
           isspace((unsigned char)*packet))
    {
        packet++;
    }

    return packet;
}

PacketType Packet_Dispatch(const char *packet)
{
    const char *p;

    if (packet == NULL)
        return PACKET_UNKNOWN;

    /*
     * Remove leading spaces, \r, \n, tabs, etc.
     */
    p = SkipWhitespace(packet);

    if (*p == '\0')
        return PACKET_UNKNOWN;

    /*
     * Compare the COMMAND only.
     *
     * This allows:
     *
     * MOVE X=10.2 Y=5.4 ROT=0
     * CHAT Hello
     *
     * while still rejecting:
     *
     * MOVEXYZ
     */
    if (strncmp(p, "HELLO", 5) == 0 &&
        (p[5] == '\0' || isspace((unsigned char)p[5])))
    {
        return PACKET_HELLO;
    }

    if (strncmp(p, "MOVE", 4) == 0 &&
        (p[4] == '\0' || isspace((unsigned char)p[4])))
    {
        return PACKET_MOVE;
    }

    if (strncmp(p, "PING", 4) == 0 &&
        (p[4] == '\0' || isspace((unsigned char)p[4])))
    {
        return PACKET_PING;
    }

    if (strncmp(p, "CHAT", 4) == 0 &&
        (p[4] == '\0' || isspace((unsigned char)p[4])))
    {
        return PACKET_CHAT;
    }

    if ((strncmp(p, "DISCONNECT", 10) == 0 &&
         (p[10] == '\0' || isspace((unsigned char)p[10]))) ||
        (strncmp(p, "QUIT", 4) == 0 &&
         (p[4] == '\0' || isspace((unsigned char)p[4]))))
    {
        return PACKET_DISCONNECT;
    }

    return PACKET_UNKNOWN;
}
