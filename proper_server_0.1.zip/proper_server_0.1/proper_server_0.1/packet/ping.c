#include "ping.h"

#include <stdio.h>

#include "../player/player.h"
#include "../network/network.h"

void Ping_Handle(struct sockaddr_in *clientAddr)
{
    int playerID;

    playerID = Player_FindByAddress(clientAddr);

    printf("[PING] Player_FindByAddress returned ID = %d\n", playerID);

    if (playerID == 0)
    {
        printf("[PING] ERROR: Player not found for this address\n");
        return;
    }

    printf("[PING] Touching heartbeat for Player %d\n", playerID);

    Player_TouchHeartbeat(playerID);

    printf("[PING] Sending PONG to Player %d\n", playerID);

    Network_SendTo("PONG", clientAddr);
}
