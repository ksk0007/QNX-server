#ifndef THREAD_H
#define THREAD_H

void Thread_Start(void);

#endif
