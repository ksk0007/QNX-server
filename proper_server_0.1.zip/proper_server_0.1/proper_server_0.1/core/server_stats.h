#ifndef SERVER_STATS_H
#define SERVER_STATS_H

#include <time.h>

typedef struct
{
    int clients;
    int packetsRX;
    int packetsTX;
    int serverPort;

    time_t startTime;

} ServerStats;

void ServerStats_Init(void);

void ServerStats_ClientConnected(void);
void ServerStats_ClientDisconnected(void);

void ServerStats_IncrementRX(void);
void ServerStats_IncrementTX(void);

int ServerStats_GetClients(void);
int ServerStats_GetPacketsRX(void);
int ServerStats_GetPacketsTX(void);
int ServerStats_GetPort(void);

long ServerStats_GetUptime(void);

ServerStats* ServerStats_Get(void);

#endif
