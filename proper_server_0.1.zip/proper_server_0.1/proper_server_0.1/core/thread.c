#include <stdio.h>
#include <pthread.h>

#include "../network/network.h"
#include "../dashboard/admin.h"
#include "scheduler.h"

static pthread_t networkThread;
static pthread_t adminThread;
static pthread_t schedulerThread;

void* Network_Task(void* arg)
{
    Network_Run();
    return NULL;
}

void* Admin_Task(void* arg)
{
    Admin_Start();
    return NULL;
}
void* Scheduler_Task(void* arg)
{
    Scheduler_Start();
    return NULL;
}

void Thread_Start(void)
{
    printf("Starting Threads...\n");

    pthread_create(&networkThread,
                   NULL,
                   Network_Task,
                   NULL);

    pthread_create(&adminThread,
                   NULL,
                   Admin_Task,
                   NULL);
    pthread_create(&schedulerThread,
                   NULL,
                   Scheduler_Task,
                   NULL);

    pthread_join(networkThread,NULL);
    pthread_join(adminThread,NULL);
    pthread_join(schedulerThread,NULL);
}
