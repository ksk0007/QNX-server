#include "scheduler.h"
#include "../dashboard/animation.h"
#include "../packet/heartbeat.h"
#include <stdio.h>
#include <unistd.h>
#include "../dashboard/dashboard.h"

void Scheduler_Start(void)
{
    printf("Scheduler Started\n");

    Animation_Init();

    int dashboardTimer = 0;

    while (1)
    {
        Heartbeat_CheckTimeouts();

        dashboardTimer++;

        if (dashboardTimer >= 60)
        {
            Dashboard_Render(stdout);
            dashboardTimer = 0;
        }

        usleep(16666);
    }
}
