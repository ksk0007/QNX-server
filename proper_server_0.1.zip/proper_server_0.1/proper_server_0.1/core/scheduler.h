#ifndef SCHEDULER_H
#define SCHEDULER_H

void Scheduler_Start(void);

#endif
