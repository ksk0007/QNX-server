#include "server_stats.h"

#include <time.h>

static ServerStats stats;

void ServerStats_Init(void)
{
    stats.clients = 0;
    stats.packetsRX = 0;
    stats.packetsTX = 0;

    stats.serverPort = 7777;

    stats.startTime = time(NULL);
}

void ServerStats_ClientConnected(void)
{
    stats.clients++;
}

void ServerStats_ClientDisconnected(void)
{
    if(stats.clients > 0)
        stats.clients--;
}

void ServerStats_IncrementRX(void)
{
    stats.packetsRX++;
}

void ServerStats_IncrementTX(void)
{
    stats.packetsTX++;
}

int ServerStats_GetClients(void)
{
    return stats.clients;
}

int ServerStats_GetPacketsRX(void)
{
    return stats.packetsRX;
}

int ServerStats_GetPacketsTX(void)
{
    return stats.packetsTX;
}

int ServerStats_GetPort(void)
{
    return stats.serverPort;
}

long ServerStats_GetUptime(void)
{
    return (long)(time(NULL) - stats.startTime);
}

ServerStats* ServerStats_Get(void)
{
    return &stats;
}
