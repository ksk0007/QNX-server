#include <stdio.h>

#include "../player/player.h"
#include "../logger/logger.h"
#include "../dashboard/dashboard.h"
#include "../network/network.h"
#include "../core/thread.h"
#include "../core/server_stats.h"
#include "../network/network.h"


int main(void)
{
    Logger_Init();

    printf("\n");
    printf("=========================================\n");
    printf("      INITIALIZING GAME SERVER...\n");
    printf("=========================================\n");

    Player_Init();
    ServerStats_Init();

    Dashboard_Init();

    if(Network_Init() != 0)
    {
        return -1;
    }

    Logger_Log(LOG_INFO, "Waiting for Unity Client...");

    Thread_Start();

    Network_Close();

    return 0;
}
