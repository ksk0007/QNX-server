#ifndef PLAYER_H
#define PLAYER_H

#include <netinet/in.h>
#include <time.h>

#define MAX_PLAYERS 2

typedef struct
{
    int id;
    int connected;

    struct sockaddr_in address;
    int has_address;

    float x;
    float y;
    float z;
    float rotation;

    int health;

    time_t lastHeartbeat;

} Player;

void Player_Init(void);

int Player_Add(void);

void Player_Remove(int id);

void Player_UpdatePosition(int id, float x, float y, float z, float rotation);

Player *Player_Get(int id);

void Player_SetAddress(int id, const struct sockaddr_in *address);

const struct sockaddr_in *Player_GetAddress(int id);

/* Identify which connected player a UDP packet came from, by matching
 * the source address recorded at HELLO time. Returns 0 if no match. */
int Player_FindByAddress(const struct sockaddr_in *address);

/* Called whenever any packet is received from a known player, so
 * heartbeat timeout checks have an up to date "last seen" time. */
void Player_TouchHeartbeat(int id);

#endif
