#include "player.h"

#include <stdio.h>
#include <string.h>

#include "../logger/logger.h"

static Player players[MAX_PLAYERS];

void Player_Init(void)
{
    int i;

    for (i = 0; i < MAX_PLAYERS; i++)
    {
        players[i].id = i + 1;
        players[i].connected = 0;

        players[i].x = 0.0f;
        players[i].y = 0.0f;
        players[i].z = 0.0f;
        players[i].rotation = 0.0f;

        players[i].health = 100;
        players[i].lastHeartbeat = 0;

        memset(&players[i].address, 0,
               sizeof(players[i].address));

        players[i].has_address = 0;
    }

    Logger_Log(LOG_INFO, "Player System Ready");
}

int Player_Add(void)
{
    int i;

    for (i = 0; i < MAX_PLAYERS; i++)
    {
        if (players[i].connected == 0)
        {
            players[i].connected = 1;
            players[i].lastHeartbeat = time(NULL);

            Logger_Log(LOG_INFO, "Player Connected");

            printf("Player ID : %d\n", players[i].id);

            return players[i].id;
        }
    }

    Logger_Log(LOG_WARNING, "Maximum Players Reached");

    return -1;
}

void Player_Remove(int id)
{
    if (id <= 0 || id > MAX_PLAYERS)
        return;

    players[id - 1].connected = 0;
    players[id - 1].has_address = 0;

    memset(&players[id - 1].address, 0,
           sizeof(players[id - 1].address));

    printf("Player %d Disconnected\n", id);
}

void Player_UpdatePosition(int id, float x, float y, float z, float rotation)
{
    if (id <= 0 || id > MAX_PLAYERS)
        return;

    players[id - 1].x = x;
    players[id - 1].y = y;
    players[id - 1].z = z;
    players[id - 1].rotation = rotation;
}

Player *Player_Get(int id)
{
    if (id <= 0 || id > MAX_PLAYERS)
        return NULL;

    return &players[id - 1];
}

void Player_SetAddress(int id, const struct sockaddr_in *address)
{
    if (id <= 0 || id > MAX_PLAYERS || address == NULL)
        return;

    players[id - 1].address = *address;
    players[id - 1].has_address = 1;
}

const struct sockaddr_in *Player_GetAddress(int id)
{
    if (id <= 0 || id > MAX_PLAYERS)
        return NULL;

    if (players[id - 1].connected == 0 ||
        players[id - 1].has_address == 0)
        return NULL;

    return &players[id - 1].address;
}

int Player_FindByAddress(const struct sockaddr_in *address)
{
    int i;

    if (address == NULL)
        return 0;

    for (i = 0; i < MAX_PLAYERS; i++)
    {
        if (!players[i].connected || !players[i].has_address)
            continue;

        if (players[i].address.sin_addr.s_addr == address->sin_addr.s_addr &&
            players[i].address.sin_port == address->sin_port)
        {
            return players[i].id;
        }
    }

    return 0;
}

void Player_TouchHeartbeat(int id)
{
    if (id <= 0 || id > MAX_PLAYERS)
        return;

    players[id - 1].lastHeartbeat = time(NULL);
}
