#ifndef ADMIN_H
#define ADMIN_H

void Admin_Start(void);

#endif
