#include "animation.h"

static unsigned long g_frame;

void Animation_Init(void) { g_frame = 0UL; }
void Animation_Update(void) { ++g_frame; }
int Animation_GetSpinnerFrame(void) { return (int)(g_frame % 4UL); }
int Animation_GetPacketOffset(void) { return (int)(g_frame % 60UL); }
int Animation_GetHeartbeat(void) { return (g_frame % 6UL) < 2UL ? 1 : 0; }
int Animation_GetNetworkBlink(void) { return (g_frame % 8UL) < 4UL ? 1 : 0; }
