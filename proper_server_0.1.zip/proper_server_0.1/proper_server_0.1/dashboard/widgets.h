#ifndef DASHBOARD_WIDGETS_H
#define DASHBOARD_WIDGETS_H

#include <stddef.h>

#define WIDGET_GRAPH_HISTORY 60

/* Original buffer-oriented widget API. */
void Widget_DrawBar(char *out, size_t out_size,
                    double value, double maximum, int width);
char Widget_Spinner(int frame);
void Widget_Heartbeat(char *out, size_t out_size, int frame);
const char *Widget_StatusDot(int is_ok);
void Widget_FormatUptime(char *out, size_t out_size, long total_seconds);

/* Graph and event storage. Values are clamped to the supplied render scale. */
void Widget_ClearGraphs(void);
void Widget_PushRX(int value);
void Widget_PushTX(int value);
int Widget_GetRX(int index);
int Widget_GetTX(int index);
int Widget_GetRXAverage(void);
int Widget_GetTXAverage(void);
int Widget_GetRXPeak(void);
int Widget_GetTXPeak(void);
void Widget_DrawRXGraph(char *out, size_t out_size, int width, int scale);
void Widget_DrawTXGraph(char *out, size_t out_size, int width, int scale);
void Widget_DrawPacketFlow(char *out, size_t out_size, int width,
                           int frame, int left_to_right);

void Widget_AddEvent(const char *message);
void Widget_ClearEvents(void);
int Widget_GetEventCount(void);
const char *Widget_GetEvent(int oldest_index);

#endif
