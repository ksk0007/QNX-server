#include "monitor.h"
#include "widgets.h"

#include <string.h>

static MonitorSnapshotProvider g_provider;
static void *g_provider_context;

static int monitor_delta(unsigned long now, unsigned long before)
{
    unsigned long delta = now >= before ? now - before : 0UL;
    return delta > 2147483647UL ? 2147483647 : (int)delta;
}

void Monitor_Init(MonitorState *state)
{
    if (state == 0) return;
    (void)memset(state, 0, sizeof(*state));
}
void Monitor_SetProvider(MonitorSnapshotProvider provider, void *context)
{
    g_provider = provider;
    g_provider_context = context;
}
int Monitor_Sample(MonitorState *state)
{
    MonitorSnapshot snapshot;
    if (state == 0 || g_provider == 0) return 0;
    if (!g_provider(&snapshot, g_provider_context)) return 0;
    Monitor_Update(state, &snapshot);
    return 1;
}
void Monitor_Update(MonitorState *state, const MonitorSnapshot *snapshot)
{
    if (state == 0 || snapshot == 0) return;
    state->current = *snapshot;
    if (state->initialized) {
        state->rx_per_second = monitor_delta(snapshot->packets_rx_total, state->previous_rx_total);
        state->tx_per_second = monitor_delta(snapshot->packets_tx_total, state->previous_tx_total);
    } else {
        state->initialized = 1;
        state->rx_per_second = 0;
        state->tx_per_second = 0;
    }
    state->previous_rx_total = snapshot->packets_rx_total;
    state->previous_tx_total = snapshot->packets_tx_total;
    Widget_PushRX(state->rx_per_second);
    Widget_PushTX(state->tx_per_second);
}
int Monitor_GetRXPerSecond(const MonitorState *state) { return state == 0 ? 0 : state->rx_per_second; }
int Monitor_GetTXPerSecond(const MonitorState *state) { return state == 0 ? 0 : state->tx_per_second; }
