#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "admin.h"
#include "dashboard.h"

#include "../player/player.h"
#include "../core/server_stats.h"
#include "../network/network.h"


/* ============================================================
 * STATUS
 * ============================================================ */

static void Admin_ShowStatus(void)
{
    Dashboard_Render(stdout);
}


/* ============================================================
 * PLAYERS
 * ============================================================ */

static void Admin_ShowPlayers(void)
{
    int i;
    int connected_count = 0;

    printf("\n");
    printf("+------------------------------------------------------------------------------+\n");
    printf("|                             CONNECTED PLAYERS                                |\n");
    printf("+------------------------------------------------------------------------------+\n");

    for (i = 1; i <= MAX_PLAYERS; i++)
    {
        Player *p;

        p = Player_Get(i);

        if (p == NULL || !p->connected)
            continue;

        printf("| PLAYER %-69d|\n", p->id);

        printf("| POS: X=%7.2f Y=%7.2f Z=%7.2f ROT=%7.2f                              |\n",
               p->x,
               p->y,
               p->z,
               p->rotation);

        printf("| HEALTH: %-3d  HEARTBEAT: %-8s                                          |\n",
               p->health,
               "ALIVE");

        printf("+------------------------------------------------------------------------------+\n");

        connected_count++;
    }

    if (connected_count == 0)
    {
        printf("| No players connected                                                         |\n");
        printf("+------------------------------------------------------------------------------+\n");
    }
}


/* ============================================================
 * HELP
 * ============================================================ */

static void Admin_ShowHelp(void)
{
    printf("\n");
    printf("+------------------------------------------------------------------------------+\n");
    printf("|                              SERVER HELP                                     |\n");
    printf("+------------------------------------------------------------------------------+\n");
    printf("| help                 Show this help                                         |\n");
    printf("| status               Show server dashboard                                  |\n");
    printf("| players              Show connected players                                 |\n");
    printf("| kick <id>            Kick a player                                           |\n");
    printf("| broadcast <message>  Send message to all players                            |\n");
    printf("| clear                Clear terminal                                          |\n");
    printf("| exit                 Stop server                                             |\n");
    printf("+------------------------------------------------------------------------------+\n");
}


/* ============================================================
 * KICK
 * ============================================================ */

static void Admin_KickPlayer(const char *command)
{
    int id;

    if (sscanf(command, "kick %d", &id) != 1)
    {
        printf("Usage: kick <player_id>\n");
        return;
    }

    if (Network_KickPlayer(id) == 0)
    {
        printf("Player %d was kicked from the server\n", id);
    }
    else
    {
        printf("Player %d is not connected\n", id);
    }
}


/* ============================================================
 * BROADCAST
 * ============================================================ */

static void Admin_Broadcast(const char *command)
{
    const char *message;
    int delivered;

    message = command + 9;

    while (*message == ' ')
        message++;

    if (*message == '\0')
    {
        printf("Usage: broadcast <message>\n");
        return;
    }

    delivered = Network_Broadcast(message);

    if (delivered > 0)
    {
        printf("Broadcast sent to %d player(s)\n", delivered);
    }
    else
    {
        printf("No connected players received the broadcast\n");
    }
}


/* ============================================================
 * ADMIN CONSOLE
 * ============================================================ */

void Admin_Start(void)
{
    char command[128];

    while (1)
    {
        printf("\nServer> ");

        if (fgets(command, sizeof(command), stdin) == NULL)
        {
            break;
        }

        command[strcspn(command, "\n")] = '\0';


        /* HELP */

        if (strcmp(command, "help") == 0)
        {
            Admin_ShowHelp();
        }


        /* STATUS */

        else if (strcmp(command, "status") == 0)
        {
            Admin_ShowStatus();
        }


        /* PLAYERS */

        else if (strcmp(command, "players") == 0)
        {
            Admin_ShowPlayers();
        }


        /* KICK */

        else if (strncmp(command, "kick ", 5) == 0)
        {
            Admin_KickPlayer(command);
        }


        /* BROADCAST */

        else if (strncmp(command, "broadcast ", 10) == 0)
        {
            Admin_Broadcast(command);
        }


        /* CLEAR */

        else if (strcmp(command, "clear") == 0)
        {
            system("clear");
        }


        /* EXIT */

        else if (strcmp(command, "exit") == 0)
        {
            printf("Stopping server...\n");
            exit(0);
        }


        /* EMPTY COMMAND */

        else if (command[0] == '\0')
        {
            continue;
        }


        /* UNKNOWN */

        else
        {
            printf("Unknown Command\n");
            printf("Type 'help' for available commands.\n");
        }
    }
}
