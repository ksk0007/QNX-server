#ifndef DASHBOARD_ANIMATION_H
#define DASHBOARD_ANIMATION_H

void Animation_Init(void);
void Animation_Update(void);
int Animation_GetSpinnerFrame(void);
int Animation_GetPacketOffset(void);
int Animation_GetHeartbeat(void);
int Animation_GetNetworkBlink(void);

#endif
