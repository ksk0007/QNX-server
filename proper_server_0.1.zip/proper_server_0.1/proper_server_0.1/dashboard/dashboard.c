#include "dashboard.h"

#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "../player/player.h"
#include "../core/server_stats.h"


static DashboardState g_dashboard;
static char g_last_packet[256];


/* ============================================================
 * DASHBOARD BORDER
 * ============================================================ */
static void dashboard_line(FILE *stream)
{
    (void)fputs(
        "+------------------------------------------------------------------------------+\n",
        stream);
}


/* ============================================================
 * INITIALIZE DASHBOARD
 * ============================================================ */
void Dashboard_Init(void)
{
    (void)memset(&g_dashboard, 0, sizeof(g_dashboard));
    (void)memset(g_last_packet, 0, sizeof(g_last_packet));

    Monitor_Init(&g_dashboard.monitor);

    g_dashboard.ansi_enabled = 1;
}


/* ============================================================
 * ENABLE / DISABLE ANSI
 * ============================================================ */
void Dashboard_SetAnsiEnabled(int enabled)
{
    g_dashboard.ansi_enabled = enabled ? 1 : 0;
}


/* ============================================================
 * ADD EVENT
 *
 * Kept for compatibility with existing code.
 * ============================================================ */
void Dashboard_AddEvent(const char *message)
{
    (void)message;
}


/* ============================================================
 * SAMPLE MONITOR
 * ============================================================ */
int Dashboard_Sample(void)
{
    return Monitor_Sample(&g_dashboard.monitor);
}


/* ============================================================
 * UPDATE MONITOR
 * ============================================================ */
void Dashboard_Update(const MonitorSnapshot *snapshot)
{
    Monitor_Update(&g_dashboard.monitor, snapshot);
}


/* ============================================================
 * STORE LAST PACKET
 * ============================================================ */
void Dashboard_SetLastPacket(const char *packet)
{
    if (packet == NULL)
    {
        g_last_packet[0] = '\0';
        return;
    }

    strncpy(g_last_packet,
            packet,
            sizeof(g_last_packet) - 1);

    g_last_packet[sizeof(g_last_packet) - 1] = '\0';
}


/* ============================================================
 * SHOW PLAYER
 * ============================================================ */
static void Dashboard_ShowPlayer(FILE *stream, int id)
{
    Player *p;
    char ip[INET_ADDRSTRLEN];

    p = Player_Get(id);

    if (p == NULL || !p->connected)
        return;

    memset(ip, 0, sizeof(ip));

    if (p->has_address)
    {
        inet_ntop(AF_INET,
                  &p->address.sin_addr,
                  ip,
                  sizeof(ip));
    }
    else
    {
        strcpy(ip, "UNKNOWN");
    }


    fprintf(stream,
            "| PLAYER %-69d|\n",
            id);


    fprintf(stream,
            "| IP: %-15s  PORT: %-5d                                             |\n",
            ip,
            p->has_address ? ntohs(p->address.sin_port) : 0);


    fprintf(stream,
            "| POS: X=%7.2f Y=%7.2f Z=%7.2f ROT=%7.2f                           |\n",
            p->x,
            p->y,
            p->z,
            p->rotation);


    fprintf(stream,
            "| HEALTH: %-3d                    HEARTBEAT: %-7s                    |\n",
            p->health,
            p->connected ? "ALIVE" : "DEAD");
}


/* ============================================================
 * RENDER DASHBOARD
 * ============================================================ */
void Dashboard_Render(FILE *stream)
{
    int i;
    int player_count;

    if (stream == NULL)
        return;


    player_count = ServerStats_GetClients();


    /* Clear terminal */
    if (g_dashboard.ansi_enabled)
    {
        (void)fputs("\033[2J\033[H", stream);
    }


    /* --------------------------------------------------------
     * TITLE
     * -------------------------------------------------------- */

    dashboard_line(stream);

    (void)fputs(
        "|                         QNX GAME SERVER                                      |\n",
        stream);

    dashboard_line(stream);


    /* --------------------------------------------------------
     * SERVER / NETWORK
     * -------------------------------------------------------- */

    fprintf(stream,
            "| STATUS                         | NETWORK                                     |\n");

    fprintf(stream,
            "| Status : %-18s | RX : %-34d |\n",
            "RUNNING",
            ServerStats_GetPacketsRX());

    fprintf(stream,
            "| Port   : %-18d | TX : %-34d |\n",
            ServerStats_GetPort(),
            ServerStats_GetPacketsTX());

    fprintf(stream,
            "| Players: %-18d | Ping: %-33s |\n",
            player_count,
            "-- ms");

    dashboard_line(stream);


    /* --------------------------------------------------------
     * PLAYERS
     * -------------------------------------------------------- */

    for (i = 1; i <= MAX_PLAYERS; i++)
    {
        Player *p;

        p = Player_Get(i);

        if (p != NULL && p->connected)
        {
            Dashboard_ShowPlayer(stream, i);

            dashboard_line(stream);
        }
    }


    /* No players */
    if (player_count == 0)
    {
        (void)fputs(
            "| NO PLAYERS CONNECTED                                                           |\n",
            stream);

        dashboard_line(stream);
    }


    /* --------------------------------------------------------
     * LAST PACKET
     * -------------------------------------------------------- */

    (void)fputs(
        "| LAST PACKET                                                                  |\n",
        stream);


    if (g_last_packet[0] != '\0')
    {
        fprintf(stream,
                "| %-76.76s |\n",
                g_last_packet);
    }
    else
    {
        (void)fputs(
            "| No packets received yet                                                     |\n",
            stream);
    }


    dashboard_line(stream);


    /* --------------------------------------------------------
     * UPTIME
     * -------------------------------------------------------- */

    fprintf(stream,
            "| Uptime: %-10ld seconds                                                   |\n",
            ServerStats_GetUptime());


    dashboard_line(stream);


    (void)fflush(stream);
}
