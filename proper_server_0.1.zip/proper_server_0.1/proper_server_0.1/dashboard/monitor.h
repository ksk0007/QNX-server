#ifndef DASHBOARD_MONITOR_H
#define DASHBOARD_MONITOR_H

#include <stddef.h>

/* The server fills this snapshot; no ServerStats/Network/Scheduler API changes are required. */
typedef struct MonitorSnapshot {
    unsigned long packets_rx_total;
    unsigned long packets_tx_total;
    long uptime_seconds;
    int player_count;
    int max_players;
    int network_online;
    int scheduler_hz;
    int cpu_percent;
    int memory_percent;
} MonitorSnapshot;

typedef int (*MonitorSnapshotProvider)(MonitorSnapshot *out, void *context);

typedef struct MonitorState {
    MonitorSnapshot current;
    unsigned long previous_rx_total;
    unsigned long previous_tx_total;
    int initialized;
    int rx_per_second;
    int tx_per_second;
} MonitorState;

void Monitor_Init(MonitorState *state);
void Monitor_SetProvider(MonitorSnapshotProvider provider, void *context);
int Monitor_Sample(MonitorState *state);
void Monitor_Update(MonitorState *state, const MonitorSnapshot *snapshot);
int Monitor_GetRXPerSecond(const MonitorState *state);
int Monitor_GetTXPerSecond(const MonitorState *state);

#endif
