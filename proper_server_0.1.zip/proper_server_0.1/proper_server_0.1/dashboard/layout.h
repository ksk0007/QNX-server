#ifndef LAYOUT_H
#define LAYOUT_H

/* Box-drawing characters (plain ASCII so it renders correctly on QNX serial
 * consoles / ttys that don't support UTF-8 box-drawing glyphs).
 * Swap these for UTF-8 (═ ║ ╔ ╗ ╚ ╝) if you know your target terminal supports it.
 */
#define BOX_H   "="
#define BOX_V   "|"
#define BOX_TL  "+"
#define BOX_TR  "+"
#define BOX_BL  "+"
#define BOX_BR  "+"
#define BOX_DIV "-"

#define DASH_WIDTH   62   /* total width of the dashboard box, in columns  */
#define BAR_WIDTH    20   /* width of progress bars (CPU/Mem/Players)      */
#define MAX_EVENTS   5     /* number of recent events shown in the log     */
#define EVENT_MSG_LEN 96

#endif /* LAYOUT_H */
