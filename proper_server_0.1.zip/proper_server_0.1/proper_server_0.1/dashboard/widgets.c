#include "widgets.h"

#include <stdio.h>
#include <string.h>

#define WIDGET_EVENT_HISTORY 20
#define WIDGET_EVENT_LENGTH  96

static int g_rx_history[WIDGET_GRAPH_HISTORY];
static int g_tx_history[WIDGET_GRAPH_HISTORY];
static char g_events[WIDGET_EVENT_HISTORY][WIDGET_EVENT_LENGTH];
static int g_event_start;
static int g_event_count;

static void widget_append(char *out, size_t out_size, size_t *position, char ch)
{
    if (*position + 1U < out_size) {
        out[*position] = ch;
        *position += 1U;
        out[*position] = '\0';
    }
}

static void widget_push(int *history, int value)
{
    int i;
    for (i = 0; i < WIDGET_GRAPH_HISTORY - 1; ++i)
        history[i] = history[i + 1];
    history[WIDGET_GRAPH_HISTORY - 1] = value < 0 ? 0 : value;
}

static void widget_draw_graph(char *out, size_t out_size, const int *history,
                              int width, int scale)
{
    static const char symbols[] = ".:-=+#%@";
    size_t position = 0U;
    int i;
    int source;
    int level;

    if (out == NULL || out_size == 0U)
        return;
    out[0] = '\0';
    if (width <= 0)
        return;
    if (width > WIDGET_GRAPH_HISTORY)
        width = WIDGET_GRAPH_HISTORY;
    if (scale <= 0)
        scale = 1;
    for (i = 0; i < width; ++i) {
        source = WIDGET_GRAPH_HISTORY - width + i;
        level = (history[source] * 8) / scale;
        if (level < 0) level = 0;
        if (level > 8) level = 8;
        widget_append(out, out_size, &position, symbols[level]);
    }
}

void Widget_DrawBar(char *out, size_t out_size,
                    double value, double maximum, int width)
{
    size_t position = 0U;
    int i;
    int filled;
    double ratio;

    if (out == NULL || out_size == 0U)
        return;
    out[0] = '\0';
    if (width <= 0)
        return;
    if (maximum <= 0.0)
        maximum = 1.0;
    ratio = value / maximum;
    if (ratio < 0.0) ratio = 0.0;
    if (ratio > 1.0) ratio = 1.0;
    filled = (int)(ratio * (double)width + 0.5);
    for (i = 0; i < width; ++i)
        widget_append(out, out_size, &position, i < filled ? '#' : '-');
}

char Widget_Spinner(int frame)
{
    static const char frames[] = "|/-\\";
    if (frame < 0) frame = -frame;
    return frames[frame % 4];
}

void Widget_Heartbeat(char *out, size_t out_size, int frame)
{
    if (out == NULL || out_size == 0U)
        return;
    (void)snprintf(out, out_size, "%s", (frame % 6) < 2 ? "<3" : "  ");
}

const char *Widget_StatusDot(int is_ok)
{
    return is_ok ? "[*]" : "[X]";
}

void Widget_FormatUptime(char *out, size_t out_size, long total_seconds)
{
    long hours;
    long minutes;
    long seconds;
    if (out == NULL || out_size == 0U)
        return;
    if (total_seconds < 0) total_seconds = 0;
    hours = total_seconds / 3600L;
    minutes = (total_seconds % 3600L) / 60L;
    seconds = total_seconds % 60L;
    (void)snprintf(out, out_size, "%02ld:%02ld:%02ld", hours, minutes, seconds);
}

void Widget_ClearGraphs(void)
{
    (void)memset(g_rx_history, 0, sizeof(g_rx_history));
    (void)memset(g_tx_history, 0, sizeof(g_tx_history));
}
void Widget_PushRX(int value) { widget_push(g_rx_history, value); }
void Widget_PushTX(int value) { widget_push(g_tx_history, value); }
int Widget_GetRX(int index) { return (index >= 0 && index < WIDGET_GRAPH_HISTORY) ? g_rx_history[index] : 0; }
int Widget_GetTX(int index) { return (index >= 0 && index < WIDGET_GRAPH_HISTORY) ? g_tx_history[index] : 0; }

static int widget_average(const int *history)
{
    int i, total = 0;
    for (i = 0; i < WIDGET_GRAPH_HISTORY; ++i) total += history[i];
    return total / WIDGET_GRAPH_HISTORY;
}
static int widget_peak(const int *history)
{
    int i, peak = 0;
    for (i = 0; i < WIDGET_GRAPH_HISTORY; ++i)
        if (history[i] > peak) peak = history[i];
    return peak;
}
int Widget_GetRXAverage(void) { return widget_average(g_rx_history); }
int Widget_GetTXAverage(void) { return widget_average(g_tx_history); }
int Widget_GetRXPeak(void) { return widget_peak(g_rx_history); }
int Widget_GetTXPeak(void) { return widget_peak(g_tx_history); }
void Widget_DrawRXGraph(char *out, size_t out_size, int width, int scale)
{ widget_draw_graph(out, out_size, g_rx_history, width, scale); }
void Widget_DrawTXGraph(char *out, size_t out_size, int width, int scale)
{ widget_draw_graph(out, out_size, g_tx_history, width, scale); }

void Widget_DrawPacketFlow(char *out, size_t out_size, int width,
                           int frame, int left_to_right)
{
    size_t position = 0U;
    int i, marker;
    if (out == NULL || out_size == 0U) return;
    out[0] = '\0';
    if (width <= 0) return;
    marker = frame % width;
    if (marker < 0) marker += width;
    if (!left_to_right) marker = width - 1 - marker;
    for (i = 0; i < width; ++i)
        widget_append(out, out_size, &position, i == marker ? (left_to_right ? '>' : '<') : '-');
}

void Widget_AddEvent(const char *message)
{
    int slot;
    if (message == NULL || message[0] == '\0') return;
    if (g_event_count < WIDGET_EVENT_HISTORY) {
        slot = (g_event_start + g_event_count) % WIDGET_EVENT_HISTORY;
        ++g_event_count;
    } else {
        slot = g_event_start;
        g_event_start = (g_event_start + 1) % WIDGET_EVENT_HISTORY;
    }
    (void)snprintf(g_events[slot], WIDGET_EVENT_LENGTH, "%s", message);
}
void Widget_ClearEvents(void)
{
    g_event_start = 0;
    g_event_count = 0;
    (void)memset(g_events, 0, sizeof(g_events));
}
int Widget_GetEventCount(void) { return g_event_count; }
const char *Widget_GetEvent(int oldest_index)
{
    if (oldest_index < 0 || oldest_index >= g_event_count) return "";
    return g_events[(g_event_start + oldest_index) % WIDGET_EVENT_HISTORY];
}
