#ifndef LOGGER_H
#define LOGGER_H

typedef enum
{
    LOG_INFO,
    LOG_WARNING,
    LOG_ERROR
} LogLevel;

void Logger_Init(void);
void Logger_Log(LogLevel level, const char *message);

#endif
