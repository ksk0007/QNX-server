#include "logger.h"

#include <stdio.h>
#include <time.h>

static const char *LevelString[] =
{
    "INFO",
    "WARN",
    "ERROR"
};

void Logger_Init(void)
{
    printf("Logger Initialized\n");
}

void Logger_Log(LogLevel level, const char *message)
{
    time_t now = time(NULL);
    struct tm *t = localtime(&now);

    printf("[%02d:%02d:%02d] [%s] %s\n",
           t->tm_hour,
           t->tm_min,
           t->tm_sec,
           LevelString[level],
           message);
}
