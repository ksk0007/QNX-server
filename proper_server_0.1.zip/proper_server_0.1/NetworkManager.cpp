using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;

public class NetworkManager : MonoBehaviour
{
    [Header("QNX Server")]
    [SerializeField] private string serverIP = "192.168.1.6";
    [SerializeField] private int serverPort = 7777;

    [Header("Local Player")]
    [SerializeField] private Transform localPlayer;

    [Header("Remote Player")]
    [SerializeField] private GameObject remotePlayerPrefab;
    [SerializeField] private Transform remotePlayerParent;

    [Header("Network Settings")]
    [SerializeField] private float moveSendInterval = 0.05f; // 20 packets/sec
    [SerializeField] private float pingInterval = 5.0f;

    private UdpClient udpClient;
    private bool socketReady = false;

    private int playerID = 0;
    private bool connected = false;

    private float moveTimer = 0f;
    private float pingTimer = 0f;

    // Remote players indexed by server Player ID
    private readonly Dictionary<int, GameObject> remotePlayers =
        new Dictionary<int, GameObject>();

    public int PlayerID => playerID;
    public bool IsConnected => connected;


    // ============================================================
    // UNITY LIFECYCLE
    // ============================================================

    private void Start()
    {
        InitializeNetwork();
    }

    private void Update()
    {
        if (!socketReady)
            return;

        ReceivePackets();

        if (!connected)
            return;

        SendMovement();
        SendPing();
    }

    private void OnApplicationQuit()
    {
        Disconnect();
    }


    // ============================================================
    // NETWORK INITIALIZATION
    // ============================================================

  private void InitializeNetwork()
{
    try
    {
        // IMPORTANT:
        // Do NOT call udpClient.Connect().
        // We want an unconnected UDP socket.

        udpClient = new UdpClient(0);

        socketReady = true;

        Debug.Log(
            $"[Network] UDP socket ready -> {serverIP}:{serverPort}"
        );

        Debug.Log(
            $"[Network] Local UDP endpoint: {udpClient.Client.LocalEndPoint}"
        );

        SendRaw("HELLO");
    }
    catch (Exception ex)
    {
        Debug.LogError(
            $"[Network] Failed to initialize: {ex}"
        );

        socketReady = false;
    }
}

    // ============================================================
    // RECEIVE
    // ============================================================

   private void ReceivePackets()
{
    if (udpClient == null || !socketReady)
        return;

    try
    {
        while (udpClient.Available > 0)
        {
            IPEndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);

            byte[] data = udpClient.Receive(ref remoteEndPoint);

            string message = Encoding.UTF8.GetString(data).Trim();

            Debug.Log(
                $"[Network RX] {message} " +
                $"FROM {remoteEndPoint.Address}:{remoteEndPoint.Port} " +
                $"BYTES={data.Length}"
            );

            HandleServerMessage(message);
        }
    }
    catch (SocketException ex)
    {
        Debug.LogError(
            $"[Network] Receive SocketException: " +
            $"{ex.SocketErrorCode} - {ex.Message}"
        );
    }
    catch (Exception ex)
    {
        Debug.LogError($"[Network] Receive error: {ex}");
    }
}

    // ============================================================
    // SERVER MESSAGE HANDLER
    // ============================================================

    private void HandleServerMessage(string message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return;

        // WELCOME
        if (message.StartsWith("WELCOME"))
        {
            HandleWelcome(message);
            return;
        }

        // UPDATE
        if (message.StartsWith("UPDATE"))
        {
            HandlePlayerUpdate(message);
            return;
        }

        // PONG
        if (message == "PONG")
        {
            Debug.Log("[Network] PONG received");
            return;
        }

        // KICK
        if (message == "KICK")
        {
            Debug.LogWarning("[Network] Server kicked this client.");
            connected = false;
            playerID = 0;
            return;
        }

        // SERVER FULL
        if (message == "SERVER_FULL")
        {
            Debug.LogWarning("[Network] Server is full.");
            connected = false;
            playerID = 0;
            return;
        }

        // BROADCAST
        if (message.StartsWith("BROADCAST"))
        {
            string broadcastMessage = message.Length > 10 ? message.Substring(10) : "";
            Debug.Log($"[Network Broadcast] {broadcastMessage}");
            return;
        }

        Debug.Log($"[Network] Unknown message: {message}");
    }


    // ============================================================
    // WELCOME
    // ============================================================

    private void HandleWelcome(string message)
    {
        Debug.Log($"[Network] Handling WELCOME packet: '{message}'");

        string[] parts = message.Split(' ');

        if (parts.Length < 2)
        {
            Debug.LogWarning("[Network] Invalid WELCOME packet.");
            return;
        }

        if (!int.TryParse(parts[1], out int receivedID))
        {
            Debug.LogWarning("[Network] Invalid player ID.");
            return;
        }

        playerID = receivedID;
        connected = true;

        Debug.Log($"[Network] Connected! Player ID = {playerID}");
    }


    // ============================================================
    // MOVEMENT
    // ============================================================

    private void SendMovement()
    {
        if (localPlayer == null)
            return;

        moveTimer += Time.deltaTime;

        if (moveTimer < moveSendInterval)
            return;

        moveTimer = 0f;

        float x = localPlayer.position.x;
        float y = localPlayer.position.y;
        float rotation = localPlayer.eulerAngles.z;

        string packet = string.Format(
            CultureInfo.InvariantCulture,
            "MOVE X={0:F2} Y={1:F2} ROT={2:F2}",
            x, y, rotation
        );

        SendRaw(packet);
    }


    // ============================================================
    // PING
    // ============================================================

    private void SendPing()
    {
        pingTimer += Time.deltaTime;

        if (pingTimer < pingInterval)
            return;

        pingTimer = 0f;

        SendRaw("PING");

        Debug.Log("[Network] PING sent");
    }


    // ============================================================
    // UPDATE FROM SERVER
    // ============================================================

    private void HandlePlayerUpdate(string message)
    {
        /*
         * Expected packet format:
         * UPDATE ID=1 X=14.22 Y=8.54 ROT=270.00
         */

        string[] parts = message.Split(' ');

        if (parts.Length < 4)
        {
            Debug.LogWarning($"[Network] Invalid UPDATE: {message}");
            return;
        }

        int id = 0;
        float x = 0f;
        float y = 0f;
        float rotation = 0f;

        foreach (string part in parts)
        {
            if (part.StartsWith("ID="))
            {
                int.TryParse(part.Substring(3), out id);
            }
            else if (part.StartsWith("X="))
            {
                float.TryParse(
                    part.Substring(2),
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out x
                );
            }
            else if (part.StartsWith("Y="))
            {
                float.TryParse(
                    part.Substring(2),
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out y
                );
            }
            else if (part.StartsWith("ROT="))
            {
                float.TryParse(
                    part.Substring(4),
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out rotation
                );
            }
        }

        if (id <= 0)
        {
            Debug.LogWarning("[Network] UPDATE has invalid player ID.");
            return;
        }

        // Ignore local player update (already managed locally)
        if (id == playerID)
            return;

        UpdateRemotePlayer(id, new Vector3(x, y, 0f), rotation);
    }


    // ============================================================
    // REMOTE PLAYER MANAGEMENT
    // ============================================================

    private void UpdateRemotePlayer(int id, Vector3 position, float rotation)
    {
        if (!remotePlayers.TryGetValue(id, out GameObject remotePlayer))
        {
            remotePlayer = CreateRemotePlayer(id);

            if (remotePlayer == null)
                return;

            remotePlayers.Add(id, remotePlayer);
        }

        remotePlayer.transform.position = position;
        remotePlayer.transform.rotation = Quaternion.Euler(0f, 0f, rotation);
    }

    private GameObject CreateRemotePlayer(int id)
    {
        if (remotePlayerPrefab == null)
        {
            Debug.LogError("[Network] Remote Player Prefab is not assigned.");
            return null;
        }

        GameObject remotePlayer;

        if (remotePlayerParent != null)
        {
            remotePlayer = Instantiate(remotePlayerPrefab, remotePlayerParent);
        }
        else
        {
            remotePlayer = Instantiate(remotePlayerPrefab);
        }

        remotePlayer.name = $"RemotePlayer_{id}";

        // Ensure remote player does not process local inputs
        PlayerController controller = remotePlayer.GetComponent<PlayerController>();
        if (controller != null)
        {
            controller.enabled = false;
        }

        PlayerInput input = remotePlayer.GetComponent<PlayerInput>();
        if (input != null)
        {
            input.enabled = false;
        }

        // Kinematic rigidbody so Unity physics does not interfere with network updates
        Rigidbody2D rb = remotePlayer.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.bodyType = RigidbodyType2D.Kinematic;
            rb.linearVelocity = Vector2.zero;
        }

        Debug.Log($"[Network] Remote Player {id} created.");

        return remotePlayer;
    }


    // ============================================================
    // SEND RAW PACKET
    // ============================================================

 public void SendRaw(string message)
{
    if (!socketReady || udpClient == null)
    {
        Debug.LogWarning("[Network] Cannot send - socket not ready.");
        return;
    }

    try
    {
        byte[] data = Encoding.UTF8.GetBytes(message);

        IPEndPoint serverEndPoint = new IPEndPoint(
            IPAddress.Parse(serverIP),
            serverPort
        );

        int sent = udpClient.Send(
            data,
            data.Length,
            serverEndPoint
        );

        Debug.Log(
            $"[Network TX SUCCESS] " +
            $"{message} ({sent} bytes) -> {serverIP}:{serverPort}"
        );
    }
    catch (Exception ex)
    {
        Debug.LogError(
            $"[Network TX ERROR] {ex}"
        );
    }
}

    // ============================================================
    // DISCONNECT
    // ============================================================

    public void Disconnect()
    {
        if (!socketReady)
            return;

        try
        {
            if (connected)
            {
                SendRaw("DISCONNECT");
            }

            connected = false;
            playerID = 0;

            udpClient?.Close();
            udpClient = null;

            socketReady = false;

            Debug.Log("[Network] Disconnected from server.");
        }
        catch (Exception ex)
        {
            Debug.LogError($"[Network] Disconnect error: {ex.Message}");
        }
    }
}