#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "admin.h"
#include "../player/player.h"

void Admin_Start(void)
{
    char command[64];

    while(1)
    {
        printf("\nServer> ");

        fgets(command,sizeof(command),stdin);

        command[strcspn(command,"\n")] = 0;

        if(strcmp(command,"help")==0)
        {
            printf("\nCommands\n");
            printf("---------------------\n");
            printf("help\n");
            printf("status\n");
            printf("players\n");
            printf("refresh\n");
            printf("clear\n");
            printf("exit\n");
        }

        else if(strcmp(command,"status")==0)
        {
            printf("\nServer Running\n");
            printf("Port : 7777\n");
        }

        else if(strcmp(command,"players")==0)
        {
            int i;

            printf("\nConnected Players\n");

            for(i=1;i<=MAX_PLAYERS;i++)
            {
                Player *p = Player_Get(i);

                if(p->connected)
                    printf("Player %d : Connected\n",i);
                else
                    printf("Player %d : Offline\n",i);
            }
        }

        else if(strcmp(command,"refresh")==0)
        {
            system("clear");

            printf("=========================================\n");
            printf("        QNX GAME SERVER\n");
            printf("=========================================\n");
        }

        else if(strcmp(command,"clear")==0)
        {
            system("clear");
        }

        else if(strcmp(command,"exit")==0)
        {
            exit(0);
        }

        else
        {
            printf("Unknown Command\n");
        }
    }
}
