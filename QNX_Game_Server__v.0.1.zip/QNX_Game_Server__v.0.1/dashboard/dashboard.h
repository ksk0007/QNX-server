#ifndef DASHBOARD_DASHBOARD_H
#define DASHBOARD_DASHBOARD_H

#include <stdio.h>

#include "monitor.h"

typedef struct DashboardState {
    MonitorState monitor;
    int ansi_enabled;
    int graph_scale;
} DashboardState;

/* Compatibility API: existing main.c can continue to call Dashboard_Init(). */
void Dashboard_Init(void);
void Dashboard_SetAnsiEnabled(int enabled);
void Dashboard_AddEvent(const char *message);
int Dashboard_Sample(void);
void Dashboard_Update(const MonitorSnapshot *snapshot);
void Dashboard_Render(FILE *stream);

#endif
