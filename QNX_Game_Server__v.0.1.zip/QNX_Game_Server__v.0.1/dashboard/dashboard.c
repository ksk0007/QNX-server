#include "dashboard.h"
#include "widgets.h"
#include "animation.h"

#include <string.h>

#define DASHBOARD_GRAPH_WIDTH 48
#define DASHBOARD_BAR_WIDTH   24

static void dashboard_line(FILE *stream)
{
    (void)fputs("+----------------------------------------------------------------+\n", stream);
}
static int dashboard_max(int a, int b) { return a > b ? a : b; }
static DashboardState g_dashboard;

void Dashboard_Init(void)
{
    (void)memset(&g_dashboard, 0, sizeof(g_dashboard));
    Monitor_Init(&g_dashboard.monitor);
    Animation_Init();
    g_dashboard.ansi_enabled = 1;
    g_dashboard.graph_scale = 100;
    Widget_ClearGraphs();
    Widget_ClearEvents();
}
void Dashboard_SetAnsiEnabled(int enabled)
{
    g_dashboard.ansi_enabled = enabled ? 1 : 0;
}
void Dashboard_AddEvent(const char *message) { Widget_AddEvent(message); }
int Dashboard_Sample(void)
{
    Animation_Update();
    return Monitor_Sample(&g_dashboard.monitor);
}
void Dashboard_Update(const MonitorSnapshot *snapshot)
{
    Animation_Update();
    Monitor_Update(&g_dashboard.monitor, snapshot);
}
void Dashboard_Render(FILE *stream)
{
    const MonitorSnapshot *m;
    char uptime[32], cpu[DASHBOARD_BAR_WIDTH + 1], memory[DASHBOARD_BAR_WIDTH + 1];
    char players[DASHBOARD_BAR_WIDTH + 1], rx_graph[DASHBOARD_GRAPH_WIDTH + 1];
    char tx_graph[DASHBOARD_GRAPH_WIDTH + 1], rx_flow[33], tx_flow[33], heartbeat[8];
    int scale;
    int i;

    if (stream == 0) return;
    m = &g_dashboard.monitor.current;
    scale = dashboard_max(g_dashboard.graph_scale,
                          dashboard_max(Widget_GetRXPeak(), Widget_GetTXPeak()));
    Widget_FormatUptime(uptime, sizeof(uptime), m->uptime_seconds);
    Widget_DrawBar(cpu, sizeof(cpu), (double)m->cpu_percent, 100.0, DASHBOARD_BAR_WIDTH);
    Widget_DrawBar(memory, sizeof(memory), (double)m->memory_percent, 100.0, DASHBOARD_BAR_WIDTH);
    Widget_DrawBar(players, sizeof(players), (double)m->player_count,
                   m->max_players > 0 ? (double)m->max_players : 1.0, DASHBOARD_BAR_WIDTH);
    Widget_DrawRXGraph(rx_graph, sizeof(rx_graph), DASHBOARD_GRAPH_WIDTH, scale);
    Widget_DrawTXGraph(tx_graph, sizeof(tx_graph), DASHBOARD_GRAPH_WIDTH, scale);
    Widget_DrawPacketFlow(rx_flow, sizeof(rx_flow), 30, Animation_GetPacketOffset(), 1);
    Widget_DrawPacketFlow(tx_flow, sizeof(tx_flow), 30, Animation_GetPacketOffset(), 0);
    Widget_Heartbeat(heartbeat, sizeof(heartbeat), Animation_GetHeartbeat() ? 0 : 3);

    if (g_dashboard.ansi_enabled) (void)fputs("\033[H\033[J", stream);
    dashboard_line(stream);
    (void)fprintf(stream, "|                 QNX REAL-TIME GAME SERVER DASHBOARD           |\n");
    dashboard_line(stream);
    (void)fprintf(stream, "| Status: %-3s RUNNING    Uptime: %-8s    Scheduler: %3d Hz %c |\n",
                  Widget_StatusDot(m->network_online), uptime, m->scheduler_hz,
                  Widget_Spinner(Animation_GetSpinnerFrame()));
    (void)fprintf(stream, "| Network: %-3s %-7s      Heartbeat: %-2s                     |\n",
                  Widget_StatusDot(m->network_online),
                  m->network_online ? "ONLINE" : "OFFLINE", heartbeat);
    (void)fprintf(stream, "| CPU:    [%s] %3d%%   Memory: [%s] %3d%% |\n",
                  cpu, m->cpu_percent, memory, m->memory_percent);
    (void)fprintf(stream, "| Players:[%s] %3d/%-3d                                  |\n",
                  players, m->player_count, m->max_players);
    dashboard_line(stream);
    (void)fprintf(stream, "| RX/s: %-6d avg:%-6d peak:%-6d scale:%-5d           |\n",
                  g_dashboard.monitor.rx_per_second, Widget_GetRXAverage(), Widget_GetRXPeak(), scale);
    (void)fprintf(stream, "| RX: %-58s |\n", rx_graph);
    (void)fprintf(stream, "| TX/s: %-6d avg:%-6d peak:%-6d                           |\n",
                  g_dashboard.monitor.tx_per_second, Widget_GetTXAverage(), Widget_GetTXPeak());
    (void)fprintf(stream, "| TX: %-58s |\n", tx_graph);
    (void)fprintf(stream, "| RX flow: %-53s |\n", rx_flow);
    (void)fprintf(stream, "| TX flow: %-53s |\n", tx_flow);
    dashboard_line(stream);
    (void)fputs("| Recent events:                                                 |\n", stream);
    for (i = 0; i < 5; ++i) {
        int event_index = Widget_GetEventCount() - 5 + i;
        const char *event = event_index >= 0 ? Widget_GetEvent(event_index) : "";
        (void)fprintf(stream, "| %-62.62s |\n", event);
    }
    dashboard_line(stream);
    (void)fflush(stream);
}
