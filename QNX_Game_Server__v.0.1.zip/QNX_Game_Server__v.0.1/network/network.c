#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "network.h"
#include "../logger/logger.h"
#include "../src/config.h"
#include "../player/player.h"
#include "../packet/dispatcher.h"
#include "../packet/hello.h"
#include "../core/server_stats.h"

static int serverSocket;

static struct sockaddr_in serverAddr;
static struct sockaddr_in clientAddr;

void Network_Close(void)
{
    close(serverSocket);
}

int Network_Init(void)
{
    Logger_Log(LOG_INFO, "Creating UDP Socket...");

    serverSocket = socket(AF_INET, SOCK_DGRAM, 0);

    if(serverSocket < 0)
    {
        Logger_Log(LOG_ERROR, "Socket Creation Failed");
        return -1;
    }

    memset(&serverAddr, 0, sizeof(serverAddr));

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(SERVER_PORT);

    if (bind(serverSocket,
             (struct sockaddr *)&serverAddr,
             sizeof(serverAddr)) < 0)
    {
        printf("\nBind Failed!\n");
        printf("errno = %d\n", errno);
        printf("Reason = %s\n", strerror(errno));

        Logger_Log(LOG_ERROR, "Bind Failed");

        return -1;
    }

    Logger_Log(LOG_INFO, "UDP Server Started");

    return 0;
}

void Network_Run(void)
{
    char buffer[BUFFER_SIZE];
    socklen_t clientLength = sizeof(clientAddr);

    while(1)
    {
        memset(buffer, 0, sizeof(buffer));

        int bytes = recvfrom(serverSocket,
                              buffer,
                              BUFFER_SIZE - 1,   /* FIX: leave room for null terminator */
                              0,
                              (struct sockaddr*)&clientAddr,
                              &clientLength);

        if(bytes > 0)
        {
        	ServerStats_IncrementRX();          // Count one received packet

            buffer[bytes] = '\0';

            printf("\n");
            printf("=================================\n");
            printf("CLIENT CONNECTED\n");
            printf("=================================\n");

            printf("IP      : %s\n", inet_ntoa(clientAddr.sin_addr));
            printf("PORT    : %d\n", ntohs(clientAddr.sin_port));
            printf("PACKET  : %s\n", buffer);

            PacketType type = Packet_Dispatch(buffer);

            switch(type)
            {
            case PACKET_HELLO:

                printf("[Dispatcher] HELLO Packet\n");

                Hello_Handle(serverSocket,
                             &clientAddr,
                             clientLength);

                break;

                case PACKET_MOVE:
                    printf("[Dispatcher] MOVE Packet\n");
                    break;

                case PACKET_PING:
                    printf("[Dispatcher] PING Packet\n");
                    break;

                default:
                    printf("[Dispatcher] UNKNOWN Packet\n");
                    break;
            }
        }
        else if(bytes < 0)
        {
            Logger_Log(LOG_WARNING, "recvfrom failed");
        }
    } /* FIX: close while loop */
} /* FIX: close function */
