#ifndef NETWORK_H
#define NETWORK_H

int Network_Init(void);

void Network_Run(void);

void Network_Close(void);

#endif
