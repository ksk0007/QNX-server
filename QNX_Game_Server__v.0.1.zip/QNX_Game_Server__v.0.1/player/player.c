#include "player.h"

#include <stdio.h>
#include "../logger/logger.h"

static Player players[MAX_PLAYERS];

void Player_Init(void)
{
    int i;

    for(i=0;i<MAX_PLAYERS;i++)
    {
        players[i].id = i + 1;
        players[i].connected = 0;

        players[i].x = 0;
        players[i].y = 0;
        players[i].z = 0;

        players[i].health = 100;
    }

    Logger_Log(LOG_INFO, "Player System Ready");
}

int Player_Add(void)
{
    int i;

    for(i = 0; i < MAX_PLAYERS; i++)
    {
        if(players[i].connected == 0)
        {
            /* Don't overwrite the player ID */
            players[i].connected = 1;

            Logger_Log(LOG_INFO, "Player Connected");

            printf("Player ID : %d\n", players[i].id);

            return players[i].id;
        }
    }

    Logger_Log(LOG_WARNING, "Maximum Players Reached");

    return -1;
}
void Player_Remove(int id)
{
    if(id <=0 || id > MAX_PLAYERS)
        return;

    players[id-1].connected = 0;

    printf("Player %d Disconnected\n", id);
}

void Player_UpdatePosition(int id,float x,float y,float z)
{
    if(id<=0 || id>MAX_PLAYERS)
        return;

    players[id-1].x = x;
    players[id-1].y = y;
    players[id-1].z = z;
}

Player* Player_Get(int id)
{
    if(id<=0 || id>MAX_PLAYERS)
        return NULL;

    return &players[id-1];
}
