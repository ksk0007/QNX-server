#ifndef PLAYER_H
#define PLAYER_H

#define MAX_PLAYERS 2

typedef struct
{
    int id;

    int connected;

    float x;
    float y;
    float z;

    int health;

} Player;

void Player_Init(void);

int Player_Add(void);

void Player_Remove(int id);

void Player_UpdatePosition(int id, float x, float y, float z);

Player* Player_Get(int id);

#endif
