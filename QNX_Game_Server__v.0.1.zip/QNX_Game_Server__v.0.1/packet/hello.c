#include "hello.h"

#include <stdio.h>
#include <string.h>
#include <sys/socket.h>

#include "../player/player.h"
#include "../logger/logger.h"
#include "../core/server_stats.h"

void Hello_Handle(int serverSocket,
                  struct sockaddr_in *clientAddr,
                  socklen_t clientLength)
{
    int playerID = Player_Add();

    ServerStats_ClientConnected();

    Logger_Log(LOG_INFO, "Player Connected");

    printf("Assigned Player ID : %d\n", playerID);

    char reply[64];

    sprintf(reply, "WELCOME %d", playerID);

    sendto(serverSocket,
           reply,
           strlen(reply),
           0,
           (struct sockaddr*)clientAddr,
           clientLength);

    ServerStats_IncrementTX();

    Logger_Log(LOG_INFO, "Reply Sent");
}
