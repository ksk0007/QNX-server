#include "dispatcher.h"

#include <string.h>

PacketType Packet_Dispatch(const char *packet)
{
    if(packet == NULL)
        return PACKET_UNKNOWN;

    if(strcmp(packet, "HELLO") == 0)
        return PACKET_HELLO;

    if(strcmp(packet, "MOVE") == 0)
        return PACKET_MOVE;

    if(strcmp(packet, "PING") == 0)
        return PACKET_PING;

    if(strcmp(packet, "CHAT") == 0)
        return PACKET_CHAT;

    if(strcmp(packet, "DISCONNECT") == 0)
        return PACKET_DISCONNECT;

    return PACKET_UNKNOWN;
}
