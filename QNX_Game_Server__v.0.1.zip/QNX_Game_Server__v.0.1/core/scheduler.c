#include "scheduler.h"
#include "../dashboard/animation.h"
#include <stdio.h>
#include <unistd.h>

void Scheduler_Start(void)
{
    printf("Scheduler Started\n");

    Animation_Init();

    while(1)
    {
        usleep(16666);
    }
}
