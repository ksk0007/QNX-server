#ifndef CONFIG_H
#define CONFIG_H

#define SERVER_PORT 7777
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 2

#endif
