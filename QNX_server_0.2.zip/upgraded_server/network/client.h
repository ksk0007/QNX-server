#ifndef CLIENT_H
#define CLIENT_H

#include <netinet/in.h>

typedef struct
{
    int connected;

    int playerId;

    struct sockaddr_in address;

} Client;

#endif
